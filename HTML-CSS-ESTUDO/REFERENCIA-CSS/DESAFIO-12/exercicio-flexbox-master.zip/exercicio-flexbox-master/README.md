# exercicio-flexbox
## Feedback exercicio

Dificuldades nessa atividade

- [X] flex-wrap: nowrap|wrap
- [ ] display: flex;
- [ ] flex-basis
- [ ] flex-grow

Mas nada impossível o desafio foi legal, principalmete no exercício 3

Copyright (c) 2018 Copyright Holder All Rights Reserved.
